
<!DOCTYPE html>
<html>
<body>

<?php  


echo "manuel array:"."<br><br>";

$matrix = array
  (
  array(1,0,0,0),
  array(0,1,0,0),
  array(0,0,1,0),
  array(0,0,0,1),
  );
  
echo $matrix[0][0].$matrix[0][1].$matrix[0][2].$matrix[0][2]."<br>";
echo $matrix[1][0].$matrix[1][1].$matrix[1][2].$matrix[1][2]."<br>";
echo $matrix[2][0].$matrix[2][1].$matrix[2][2].$matrix[2][3]."<br>";
echo $matrix[3][0].$matrix[3][1].$matrix[3][2].$matrix[3][3]."<br>";


echo "<br><br>";
echo "array med loop:"."<br><br>";

// jeg skal bruge $row og $col i arrayen, samt gøre det en gang først og lægge en til


  $matrix = array();
  $n = 10;
  for ($i = 0; $i < $n; $i++)
  {
      $row = array_fill(0,$i,0);
      $row[$i] = 1;
      $matrix[] = $row;
      print_r($row);
      echo "<br>";
      
      
      
      //foreach ($i )
      
      //echo "i ". $i. "<br>";
     // echo "n ". $n. "<br>";
  }
  //foreach ()
   //   echo $matrix[0][0];
      //echo "<br>"

      



?>  

</body>
</html>