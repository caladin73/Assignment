<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>be00 identity matrix</title>
    </head>
    <body>
        <h1>Peter Myrvig bb00</h1>
        <?php
        
// function to create matrix and store values, after each loop

        function createMatrix($size)
{
    $result = array();

    for ($i = 0; $i < $size; $i++) {
        $row      = array_fill(0, $size, 0);
        $row[$i]  = 1;
        $result[] = $row;
    }

    return $result;
}

// 2 loops for row and colum, to print the identify matrix 

function printMatrix(array $matrix)
{
    foreach ($matrix as $row) {
        foreach ($row as $column) {
            echo $column . " ";
        }
        echo "<br>".PHP_EOL;
    }
    echo PHP_EOL;
}

// n = row and colum, in an identity matrix

$n = 10;
printMatrix(createMatrix($n));

        
        
        ?>
    </body>
</html>
