<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
    // I get 3 numbers from and html form
    //$_GET["number1"]
    //$_GET["number2"]
    //$_GET["number3"]
    
    // 1) Place the numbers in an array
    $get_numbers = array
            (
        $_GET["number1"],
        $_GET["number2"],
        $_GET["number3"],
            );
    echo "2) Print the array <br>";
    $arrlength = count($get_numbers);
       
    for($x = 0; $x < $arrlength; $x++) 
    {
    echo $get_numbers[$x];
    echo "<br>";
    }
    
    echo "<br>3) The smallest number is: ";
    $min = min($get_numbers);
    echo $min. "<br>";
    
    
    echo "<br>4) The smallest number is: ";
    $max = max($get_numbers);
    echo $max. "<br>"

       
        
        
        
        
        ?>
    </body>
</html>
