    <?php

    // Angels in degrees
    // Areal of triangle
    // 
    // The cosine function in PHP is cos($angleInRad)
    // The inverse of cosine in PHP acos($cosOfAngle)
    // PHP has a rad2deg($angleInRad) to convert radians to degrees 
    // The inverse of rad2deg($angleInRad) is deg2rad($angleInDeg)
    // And the PHP square root is sqrt($somenumber)
    // 
    // 4)Lengths of the three sides of the triangle. You may use the Pythagorean theorem to calculate the result
        
    // Da jeg ikke ved om trekanten er retvinklet, kan jeg ikke bruge Pythagoras læresætning!
    // Derfor bruger jeg afstandformlen, da jeg kender alle kordinaterne: 
    // Afstanden mellem DE er givet ved: |DE| = sqrt((x2-x1)¨2+(y2-y1)¨2)
            
    $DE = (sqrt(((pow(($x2-$x1),2))+(pow(($y2-$y1),2)))));
    $EF = (sqrt(((pow(($x2-$x3),2))+(pow(($y2-$y3),2)))));
    $DF = (sqrt(((pow(($x1-$x3),2))+(pow(($y1-$y3),2)))));
    
    echo "<br>";
    echo "DE: ". $DE. "<br>";
    echo "EF: ". $EF. "<br>";
    echo "DF: ". $DF. "<br>";
    echo "<br>";
    
    //Vinklerne kan man regne ud ved hjælp af cosinusrelationen:
    // cos C = (a2 + b2 - c2) / (2ab)
    // cos F = (EF2 + DF2 - DE2) / (2*EF*DF)

    $radD = acos(($DF*$DF+$DE*$DE-$EF*$EF)/(2*$DF*$DE));
    $radE = acos(($EF*$EF+$DE*$DE-$DF*$DF)/(2*$EF*$DE));
    $radF = acos(($EF*$EF+$DF*$DF-$DE*$DE)/(2*$EF*$DF));

    echo "Vinkel D: ". rad2deg($radD). "<br>";
    echo "Vinkel E: ". rad2deg($radE). "<br>";
    echo "Vinkel F: ". rad2deg($radF). "<br>";
    
    // Areal kan regnes ud ved hjælp af ablesin formlen:
    // T = (1/2)*ab*sin(C)
    // T= 0,5*EF*DF*$radD
   
   echo "<br>Areal: ";
   echo 0.5*$EF*$DF*sin($radF);
  
   
    
     
        
        
       
        
        
        
        
        
        
        
        
        
        
        
        
    ?>

