<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>be01 </title>
    </head>
    <body>
        <h2><p>Peter Myrvig</p></h2>     

    <?php
    
    // I get these numbers from the html page and sit up an if, elseif, else statement
    //$_GET["number1"]
    //$_GET["number2"]
    //$_GET["number3"]
    
    if ($_GET["number1"] > $_GET["number2"] and $_GET["number1"] > $_GET["number3"]) {
    echo "The biggest number is: ". $_GET["number1"];
    } elseif ($_GET["number2"] > $_GET["number1"] and $_GET["number2"] > $_GET["number3"]) {
    echo "The biggest number is: ". $_GET["number2"];
    } else {
    echo "The biggest number is: ". $_GET["number3"];
    }
           
    ?>    
           
    </body>
</html>
